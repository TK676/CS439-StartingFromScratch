﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyFollowScript : MonoBehaviour
{
    public Transform playerCube;
    public float speed;
    public float touchingDistance = .5f;
    public bool touchedPlayer = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Follow the player

        if (!touchedPlayer)
        {
            transform.position = Vector3.MoveTowards(transform.position, playerCube.transform.position, speed * Time.deltaTime);
        }
        

        //Check Distance from player
        if (Vector3.Distance(transform.position, playerCube.transform.position) < touchingDistance)
        {
            touchedPlayer = true;
        }
    }
}
