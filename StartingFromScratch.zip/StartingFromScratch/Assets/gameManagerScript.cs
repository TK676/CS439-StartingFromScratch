﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameManagerScript : MonoBehaviour
{
    public movementScript player;
    public GameObject[] Enemys;
    public GameObject winText;
    public GameObject loseText;
    public GameObject resetButton;

    public bool gameEnded = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!gameEnded)
        { 
            GameObject[] items = GameObject.FindGameObjectsWithTag("item");

            //PlzyerWon
            if (items.Length == 0)
            {
                Debug.Log("Won");

                for (int j = 0; j < Enemys.Length; j++)
                {
                    Enemys[j].GetComponent<enemyFollowScript>().touchedPlayer = true;
                }

                winText.SetActive(true);
                resetButton.SetActive(true);

                player.canMove = false;
                gameEnded = true;
            }

            //Ploayer loses
            for (int i = 0; i < Enemys.Length; i++)
            {
                if (Enemys[i].GetComponent<enemyFollowScript>().touchedPlayer && player.canMove)
                {
                    Debug.Log("Lost");

                    for (int j = 0; j < Enemys.Length; j++)
                    {
                        Enemys[j].GetComponent<enemyFollowScript>().touchedPlayer = true;
                    }

                    loseText.SetActive(true);
                    resetButton.SetActive(true);

                    player.canMove = false;
                    gameEnded = true;
                }
            }
        }
    }
}
